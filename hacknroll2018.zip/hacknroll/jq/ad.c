#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main()
{
  char inputssid[100],inputvol[100];
  char ssid[100];
  char filessid_name[100] = "ssid_";
  char filevolume_name[100] = "volume_";
  char filessid_name1[100] = "ssid_";
  char numword[100],iword[100];
  int num, i;
//int modified;
  FILE *ssid_ptr,*num_ptr,*vol_ptr;

  scanf("%s ",inputssid);
  printf("\n");
  scanf("%s",inputvol);
  printf("\n");
  if((num_ptr=fopen("numstorage.txt","r+"))==NULL) {return 0;}

  fgets(numword,100,num_ptr);
num=atoi(numword); // num extracted

for (i=0;i<num;i++)
{
  itoa(i,iword, 10);
  strcat(filessid_name,iword);
  ssid_ptr = fopen(filessid_name,"r+"); fgets(ssid,100,ssid_ptr);

  if(strcmp(ssid,inputssid)==0)
  {
    printf("hi\n"); //for debugging
    strcat(filevolume_name,iword);
    vol_ptr=fopen(filevolume_name,"w+"); fputs(inputvol , vol_ptr);
    fclose(vol_ptr);
    fclose(ssid_ptr);
    fclose(num_ptr);
    return 0;
  }

}

fclose(ssid_ptr);
strcat(filessid_name1,numword);
ssid_ptr = fopen(filessid_name1,"a+");
fputs(inputssid,ssid_ptr);
fclose(ssid_ptr);

strcat(filevolume_name,numword);
vol_ptr=fopen(filevolume_name,"a+");
fputs(inputvol,vol_ptr);
fclose(vol_ptr);

num = num+1;
itoa(num,numword,10);

fclose(num_ptr);
num_ptr=fopen("numstorage.txt","w+");
fputs(numword,num_ptr);
fclose(num_ptr);

return 0;
}

