#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main()
{
	int i,sum,indicator=0;
	char num[3];
	FILE *wiki_ptr;
	char text[100];
	FILE *paragraph_ptr;
	char file_name[20]="wikiparagraph_";
	wiki_ptr = fopen("c5wikitext.txt","r+");
	paragraph_ptr = fopen("wikiparagraph_0","a+");

	while(fgets(text,100,wiki_ptr))
	{
		for(i=0;i<strlen(text);i++){sum+=(int)text[i];}
		printf("%d,%s",i-1,text);
		printf("--%d-%d--",sum,indicator);


		if(sum==10) // enter this if block when the whole text line ocontains only '\n' ,because \n = 10 in ascii value as shown by <printf("%d",'\n');>
		{
			fclose(paragraph_ptr);
			indicator+=1;  //plus one
			itoa(indicator,num,10); //convert 'int type' to 'string type'
			strcat(file_name,num); //set new file name to write to
			paragraph_ptr = fopen(file_name,"a+");  //file pointer now points to another file with a different file name, leaving the previous paragraph unharmed.
		}
//however
//this will create empty file if, in the c5wikitext.txt, [ENTER] is hit twice or more to separate 2 consecutive paragraphs, i.e. multiple lines of only '\n'

		fputs(text,paragraph_ptr);



		sum=0;

	}

	printf("\n\n%d",sum);
	fclose(wiki_ptr);
	fclose(paragraph_ptr);

return 0;
}
